# jlPlayer
A simple custom HTML5 video player
